"use client"

import BlogPost from "../src/app/blog/[slug]/page"

export default function SyntheticV0PageForDeployment() {
  return <BlogPost />
}