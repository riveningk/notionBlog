import { WritePostForm } from "@/components/write-post-form"

export default function WritePage() {
  return <WritePostForm />
}
